package main

import (
	"context"
	"log"
	"net/http"

	appdb "github.com/airtonlira/opentelemetry/internal/migration"
	"github.com/airtonlira/opentelemetry/internal/routes"

	"github.com/gorilla/mux"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/sdk/resource"
	"go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.4.0"
)

func initTracer() (*trace.TracerProvider, error) {
	ctx := context.Background()

	// Cria o exportador usando o protocolo OTLP/HTTP
	exporter, err := otlptracehttp.New(ctx)
	if err != nil {
		return nil, err
	}

	// Configura o TracerProvider com o exportador
	tp := trace.NewTracerProvider(
		trace.WithBatcher(exporter),
		trace.WithResource(resource.NewWithAttributes(
			semconv.SchemaURL,
			semconv.ServiceNameKey.String("my-go-service"),
		)),
	)

	otel.SetTracerProvider(tp)
	return tp, nil
}

func main() {
	// Inicializa o TracerProvider com OpenTelemetry
	tp, err := initTracer()
	if err != nil {
		log.Fatalf("failed to initialize tracer: %v", err)
	}
	defer tp.Shutdown(context.Background())

	// Verificar ou criar banco de dados
	err = appdb.EnsureDatabaseExists()
	if err != nil {
		log.Fatalf("Falha ao garantir que o banco de dados existe: %v", err)
		return
	}

	// Verificar e criar tabelas
	err = appdb.EnsureTablesExist()
	if err != nil {
		log.Fatalf("Falha ao garantir que as tabelas existem: %v", err)
		return
	}

	// Cria um roteador
	router := mux.NewRouter()

	// Registra as rotas para contas e pagamentos
	routes.RegisterRoutes(router)

	log.Println("Server is running on :8080")
	log.Fatal(http.ListenAndServe(":8080", router))
}
